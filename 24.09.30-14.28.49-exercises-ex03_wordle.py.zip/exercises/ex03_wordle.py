"""A take on the famous Wordle game!"""

__author__ = "730675588"


def input_guess(secret_word_len: int) -> str:
    """Will take a word as input and return it if it is the same
    length as the secret word"""
    input_word: str = input(f"Enter a {secret_word_len} character word: ")
    while len(input_word) != secret_word_len:
        if secret_word_len == 1:
            input_word = input(f"That wasn't {secret_word_len} char! Try again: ")
        else:
            input_word = input(f"That wasn't {secret_word_len} chars! Try again: ")
    return input_word


def contains_char(secret_word: str, char_guess: str) -> bool:
    """Goes through the secret word, returning True if a specific character
    is within the word, and otherwise False"""
    assert len(char_guess) == 1
    index: int = 0
    while index < len(secret_word):
        if secret_word[index] == char_guess:
            return True
        index += 1
    return False


"""Need to make sure that if letter is in word but the letter has already
been checked green, do not mark future instances of the letter as yellow.
Should be marked as white (make a string of the secret word, remove
the characters if they are checked as green and do char check with that)"""


def emojified(secret_word: str, guess_word: str) -> str:
    """Compares a guessed word to a secret word character by character,
    marking with a green box if the character from the guess and secret
    words are the same, yellow if they are not but are still in the secret word,
    and white if the character is not in the secret word"""
    assert len(guess_word) == len(secret_word)
    WHITE_BOX: str = "\U00002B1C"
    GREEN_BOX: str = "\U0001F7E9"
    YELLOW_BOX: str = "\U0001F7E8"
    index: int = 0
    emoji: str = ""
    secret_word_check: str = secret_word
    while index < len(secret_word):
        if guess_word[index] == secret_word[index]:
            emoji += GREEN_BOX
            secret_word_check = (
                secret_word_check[:index] + " " + secret_word_check[1 + index :]
            )
        elif contains_char(secret_word=secret_word_check, char_guess=guess_word[index]):
            check_index: int = 0
            flag: int = 0
            while check_index < len(secret_word):
                if (
                    secret_word[check_index] == guess_word[check_index]
                    and secret_word[index] == secret_word[check_index]
                ):
                    flag += 1
                check_index += 1
            if flag == 0:
                """Thinking while loop here, runs through the emoji string, sees
                if there is a yellow and what character that corresponds to in
                guess_word, if there are more instances of characters in guess than
                secret, it will make the characters yellow until that number, then
                make the rest of that character white."""
                emoji += YELLOW_BOX
            else:
                emoji += WHITE_BOX
            """Needs to return a number of yellows equal to the number of characters
            of that type that are in the secret word (ie. if the word is 'bossy'
            and I type in 'sssys', emojify should return 'ywgww', not 'yygwy')"""
        else:
            emoji += WHITE_BOX
        index += 1
    return emoji


def main(secret: str) -> None:
    """Runs the above functions on a Wordle-Styled interface!"""
    turn: int = 1
    while turn < 7:
        print(f"=== Turn {turn}/6 ===")
        guess: str = input_guess(secret_word_len=len(secret))
        print(emojified(secret_word=secret, guess_word=guess))
        if secret == guess:
            print(f"You won in {turn}/6 turns!")
            turn = 7
        turn += 1
        if turn == 7:
            print("X/6 - Sorry, try again tomorrow!")


if __name__ == "__main__":
    main(secret="bossy")
